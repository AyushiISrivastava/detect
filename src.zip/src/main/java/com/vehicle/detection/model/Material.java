package com.vehicle.detection.model;

/**
 * Created by Ayushi on 23/01/19.
 */
public class Material {

	public String material;

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}
}
