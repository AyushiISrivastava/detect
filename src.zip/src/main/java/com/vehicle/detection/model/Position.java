package com.vehicle.detection.model;

/**
 * Created by Ayushi on 23/01/19.
 */
public class Position {

	public String position;

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
}
