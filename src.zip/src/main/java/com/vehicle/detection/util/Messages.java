package com.vehicle.detection.util;

/**
 * Created by Ayushi on 21/01/19.
 */
public class Messages {
	public static final String INVALID_INPUT = "Input is invalid";
	public static final String RECORD_FETCHED = "Records Fetched";
	public static final String RECORD_SAVED = "Success";
	public static final String NO_DATA = "No data";
	public static final String RECORD_NOT_FETCHED = "Record not fetched";
}
